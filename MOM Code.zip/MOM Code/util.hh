

#define CONJ -1
#define NO_CONJ 1
#define TRANS 1
#define NO_TRANS 0
#define NO_BALANIS 0 
#define BALANIS 1

/*
 *  File:		set_up_and_discretise_plate.h
 *  Project:	3D EFIE MOM
 *
 *  Created by Conor Brennan on 19/07/2011.
 *  Copyright 2011 Dublin City University. All rights reserved.
 *
 */

using namespace std ;


void set_up_plate_parameters() ; 
void initialise_the_square() ; 
void make_a_fine_grid_of_squares()  ; 
void make_the_basis_fns() ; 




